"use client"

import { useEffect, useState } from "react"
import { TrendingUp, Activity, Zap } from "lucide-react"

interface Signal {
  symbol: string
  strike: number
  option_type: string
  entry_price: number
  confidence: number
  reason: string
  timestamp: string
}

export default function TradingDashboard() {
  const [signals, setSignals] = useState<Signal[]>([])
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    totalSignals: 0,
    avgConfidence: 0,
    activeSignals: 0,
  })

  const fetchSignals = async () => {
    try {
      const response = await fetch(
        "https://raw.githubusercontent.com/athreya9/my-trading-platform/main/data/signals.json",
      )
      const data = await response.json()
      setSignals(data)

      // Calculate stats
      const total = data.length
      const avg = data.reduce((acc: number, s: Signal) => acc + s.confidence, 0) / total
      const active = data.filter((s: Signal) => {
        const signalTime = new Date(s.timestamp).getTime()
        const now = Date.now()
        return now - signalTime < 3600000 // Active if less than 1 hour old
      }).length

      setStats({
        totalSignals: total,
        avgConfidence: Math.round(avg * 100),
        activeSignals: active,
      })
      setLoading(false)
    } catch (error) {
      console.error("[v0] Error fetching signals:", error)
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchSignals()
    const interval = setInterval(fetchSignals, 15000) // Auto-refresh every 15s
    return () => clearInterval(interval)
  }, [])

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp)
    return date.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })
  }

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return "from-green-400 to-emerald-500"
    if (confidence >= 0.6) return "from-yellow-400 to-orange-500"
    return "from-red-400 to-pink-500"
  }

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      {/* Animated gradient background */}
      <div className="fixed inset-0 bg-gradient-to-br from-purple-900/20 via-black to-cyan-900/20 animate-gradient-shift" />
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-pink-500/10 via-transparent to-transparent" />

      <div className="relative z-10 container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <header className="mb-12 text-center">
          <h1 className="text-6xl font-bold mb-4 bg-gradient-to-r from-purple-400 via-pink-500 to-cyan-400 bg-clip-text text-transparent animate-gradient-x">
            🚀 AI TRADING PLATFORM
          </h1>
          <p className="text-gray-400 text-lg">Real-time signals powered by artificial intelligence</p>
        </header>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="group relative overflow-hidden rounded-2xl bg-gradient-to-br from-purple-500/10 to-purple-900/10 backdrop-blur-xl border border-purple-500/20 p-6 hover:border-purple-500/50 transition-all duration-300 hover:scale-105 hover:shadow-[0_0_30px_rgba(168,85,247,0.4)]">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-2">Total Signals</p>
                <p className="text-4xl font-bold text-purple-400">{stats.totalSignals}</p>
              </div>
              <TrendingUp className="w-12 h-12 text-purple-500 opacity-50" />
            </div>
          </div>

          <div className="group relative overflow-hidden rounded-2xl bg-gradient-to-br from-pink-500/10 to-pink-900/10 backdrop-blur-xl border border-pink-500/20 p-6 hover:border-pink-500/50 transition-all duration-300 hover:scale-105 hover:shadow-[0_0_30px_rgba(236,72,153,0.4)]">
            <div className="absolute inset-0 bg-gradient-to-br from-pink-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-2">Avg Confidence</p>
                <p className="text-4xl font-bold text-pink-400">{stats.avgConfidence}%</p>
              </div>
              <Activity className="w-12 h-12 text-pink-500 opacity-50" />
            </div>
          </div>

          <div className="group relative overflow-hidden rounded-2xl bg-gradient-to-br from-cyan-500/10 to-cyan-900/10 backdrop-blur-xl border border-cyan-500/20 p-6 hover:border-cyan-500/50 transition-all duration-300 hover:scale-105 hover:shadow-[0_0_30px_rgba(34,211,238,0.4)]">
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-2">Active Signals</p>
                <p className="text-4xl font-bold text-cyan-400">{stats.activeSignals}</p>
              </div>
              <Zap className="w-12 h-12 text-cyan-500 opacity-50" />
            </div>
          </div>
        </div>

        {/* Live Signals Section */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-gray-900/50 to-gray-800/50 backdrop-blur-xl border border-gray-700/50 p-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
              Live Signals
            </h2>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-sm text-gray-400">Live</span>
            </div>
          </div>

          {loading ? (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="flex gap-2 mb-4">
                <div className="w-3 h-3 rounded-full bg-purple-500 animate-bounce" style={{ animationDelay: "0ms" }} />
                <div className="w-3 h-3 rounded-full bg-pink-500 animate-bounce" style={{ animationDelay: "150ms" }} />
                <div className="w-3 h-3 rounded-full bg-cyan-500 animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
              <p className="text-gray-400">Loading signals...</p>
            </div>
          ) : signals.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="flex gap-2 mb-4">
                <div className="w-3 h-3 rounded-full bg-purple-500 animate-pulse" style={{ animationDelay: "0ms" }} />
                <div className="w-3 h-3 rounded-full bg-pink-500 animate-pulse" style={{ animationDelay: "300ms" }} />
                <div className="w-3 h-3 rounded-full bg-cyan-500 animate-pulse" style={{ animationDelay: "600ms" }} />
              </div>
              <p className="text-gray-400 text-lg">No signals available</p>
              <p className="text-gray-500 text-sm mt-2">Waiting for AI to generate new signals...</p>
            </div>
          ) : (
            <div className="grid gap-4">
              {signals.map((signal, index) => (
                <div
                  key={index}
                  className="group relative overflow-hidden rounded-xl bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm border border-gray-700/50 p-6 hover:border-purple-500/50 transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_0_20px_rgba(168,85,247,0.3)]"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-500/5 via-pink-500/5 to-cyan-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />

                  <div className="relative grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
                    {/* Symbol & Strike */}
                    <div className="md:col-span-3">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center font-bold text-lg">
                          {signal.symbol.substring(0, 2)}
                        </div>
                        <div>
                          <p className="font-bold text-lg text-white">{signal.symbol}</p>
                          <p className="text-sm text-gray-400">Strike: {signal.strike}</p>
                        </div>
                      </div>
                    </div>

                    {/* Option Type */}
                    <div className="md:col-span-2">
                      <span
                        className={`inline-block px-3 py-1 rounded-full text-xs font-bold ${
                          signal.option_type === "CE"
                            ? "bg-green-500/20 text-green-400 border border-green-500/50"
                            : "bg-red-500/20 text-red-400 border border-red-500/50"
                        }`}
                      >
                        {signal.option_type}
                      </span>
                    </div>

                    {/* Entry Price */}
                    <div className="md:col-span-2">
                      <p className="text-xs text-gray-400 mb-1">Entry Price</p>
                      <p className="text-xl font-bold text-cyan-400">₹{signal.entry_price}</p>
                    </div>

                    {/* Confidence */}
                    <div className="md:col-span-2">
                      <p className="text-xs text-gray-400 mb-2">Confidence</p>
                      <div className="relative w-full h-2 bg-gray-700 rounded-full overflow-hidden">
                        <div
                          className={`absolute inset-y-0 left-0 bg-gradient-to-r ${getConfidenceColor(signal.confidence)} rounded-full transition-all duration-500`}
                          style={{ width: `${signal.confidence * 100}%` }}
                        />
                      </div>
                      <p className="text-xs font-bold text-white mt-1">{Math.round(signal.confidence * 100)}%</p>
                    </div>

                    {/* AI Reasoning */}
                    <div className="md:col-span-2">
                      <p className="text-sm text-gray-300 line-clamp-2">{signal.reason}</p>
                    </div>

                    {/* Timestamp */}
                    <div className="md:col-span-1 text-right">
                      <p className="text-xs text-gray-500">{formatTime(signal.timestamp)}</p>
                      <span className="inline-block mt-1 px-2 py-1 rounded-full text-xs font-bold bg-green-500/20 text-green-400 border border-green-500/50">
                        LIVE
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
